<ul class="sidebar-menu">
    <li><a href="user.php"><i class="fa fa-user-circle-o"></i><span>Data User</span></a></li>
    <li class="header"><h4><b><center>DATA MASTER</center></b></h4></li>
    <li><a href="pegawai.php"><i class="fa fa-users"></i><span>Data Pegawai</span></a></li>
    <li><a href="pelanggan.php"><i class="fa fa-users"></i><span>Data Pelanggan</span></a></li>
    <li><a href="supplier.php"><i class="fa fa-users"></i><span>Data Supplier</span></a></li>
    <li><a href="barang.php"><i class="fa fa-users"></i><span>Data Barang</span></a></li>
    <li><a href="produk.php"><i class="fa fa-users"></i><span>Data Produk</span></a></li>
    <li><a href="produksi.php"><i class="fa fa-users"></i><span>Data Produksi</span></a></li>
    <li><a href="formula.php"><i class="fa fa-users"></i><span>Data Formula</span></a></li>
    <li><a href="kendaraan.php"><i class="fa fa-users"></i><span>Data Kendaraan</span></a></li>
    <li class="header"><h4><b><center>DATA PESANAN</center></b></h4></li>
    <li><a href="customer.php"><i class="fa fa-users"></i><span>Data Pesanan</span></a></li>
    <li><a href="invoice/index.php"><i class="fa fa-users"></i><span>Invoice</span></a></li>
</ul>
