<header class="main-header">
  <!-- Logo -->
  	<div class="logo">

  	</div>
  <!-- Header Navbar: style can be found in header.less -->
  	<nav class="navbar navbar-static-top" role="navigation">
    <!-- Sidebar toggle button-->
    	<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
      		<span class="sr-only">Toggle navigation</span>
      		<span class="icon-bar"></span>
      		<span class="icon-bar"></span>
      		<span class="icon-bar"></span>
	  </a>
  	</nav>
</header>

<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <ul class="sidebar-menu">
		<li><a href="index.php">
     		 <i class="fa fa-user-circle-o"></i>
      		 <span>DASHBOARD</span></a>
      	</li>
      	<li><a href="../client/index.php">
  			  <i class="fa fa-files-o"></i>
  			  <span>ANTRIAN</span>
          </a>
       	</li>
        <li><a href="index.php?pendaftaran">
  			  <i class="fa fa-files-o"></i>
  			  <span>PENDAFTARAN</span>
          </a>
       	</li>
       	<li><a href="index.php?history-daftar">
     		 <i class="fa fa-files-o"></i>
      		 <span>HISTORY</span></a>
      	</li>
        <li><a href="index.php?data-dokter">
          <i class="fa fa-user-o"></i>
          <span>DATA DOKTER</span>
          </a>
        </li>
        <li><a href="index.php?data-pasien">
  			  <i class="fa fa-user-o"></i>
  			  <span>DATA PASIEN</span>
          </a>
       	</li>
     	  <li><a href="../logout.php">
			  <i class="fa fa--o"></i>
			  <span>LOGOUT</span>
        	</a>
     	  </li>
	</ul>
  </section>
  <!-- /.sidebar -->
</aside>
